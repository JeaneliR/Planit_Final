package com.planitatf3.planitatf3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Planitatf3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
