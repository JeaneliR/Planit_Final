document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('calendar');

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'es',
        events: '/api/eventos',

        eventDidMount: function (info) {
            const estado = info.event.extendedProps.status;
            const el = info.el;

            if (estado === 'completado') {
                el.classList.add('bg-success', 'text-white');
            } else if (estado === 'pendiente') {
                el.classList.add('bg-warning', 'text-dark');
            } else if (estado === 'vencido') {
                el.classList.add('bg-danger', 'text-white');
            }

            new bootstrap.Tooltip(el, {
                title: info.event.extendedProps.description || 'Sin descripción',
                placement: 'top',
                trigger: 'hover',
                container: 'body'
            });
        },

        dateClick: function (info) {
            window.location.href = '/MisTareas?fecha=' + info.dateStr;
        },

        eventClick: function (info) {
            const event = info.event;
            const fecha = new Date(event.start).toLocaleString('es-PE', {
                dateStyle: 'medium',
                timeStyle: 'short'
            });

            // Llenar el modal
            document.getElementById('modalTitulo').textContent = event.title;
            document.getElementById('modalFecha').textContent = fecha;
            document.getElementById('modalDescripcion').textContent =
                event.extendedProps.description || 'Sin descripción';

            // Mostrar el modal
            const modal = new bootstrap.Modal(document.getElementById('tareaModal'));
            modal.show();
        }
    });

    calendar.render();
});
