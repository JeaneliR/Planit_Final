document.addEventListener("DOMContentLoaded", function () {
    const toggleMode = document.getElementById("toggleMode");

    // Comprobar si el usuario ya activó el modo oscuro anteriormente
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        toggleMode.checked = true;
    }

    // Alternar modo oscuro al cambiar el interruptor
    toggleMode.addEventListener("change", function () {
        document.body.classList.toggle("dark-mode", toggleMode.checked);
        localStorage.setItem("darkMode", toggleMode.checked ? "enabled" : "disabled");
    });

    // Sidebar toggle con flechita
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.getElementById('toggleSidebar');

    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('hidden');
        toggleBtn.textContent = sidebar.classList.contains('hidden') ? '⮞' : '⮜';
    });

    // 📊 Generar gráfico con Chart.js desde datos del backend
    fetch("/estadisticas")
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('tasksChart').getContext('2d');
            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['Completadas', 'Pendientes'],
                    datasets: [{
                        data: [data.completadas, data.pendientes],
                        backgroundColor: ['#28a745', '#dc3545']
                    }]
                }
            });
        })
        .catch(error => console.error("Error al obtener las estadísticas:", error));
});
