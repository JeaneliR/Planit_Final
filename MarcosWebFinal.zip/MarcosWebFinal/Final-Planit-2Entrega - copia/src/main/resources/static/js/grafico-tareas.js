document.addEventListener("DOMContentLoaded", function () {
  const canvas = document.getElementById("graficoTareas");
  if (!canvas) return;

  fetch("/estadisticas")
    .then((response) => response.json())
    .then((data) => {
      const completadas = data.completadas || 0;
      const pendientes = data.pendientes || 0;

      new Chart(canvas, {
        type: "doughnut",
        data: {
          labels: ["Completadas", "Pendientes"],
          datasets: [
            {
              label: "Tareas",
              data: [completadas, pendientes],
              backgroundColor: ["#198754", "#ffc107"], // verde y amarillo
              borderColor: ["#157347", "#ffca2c"],
              borderWidth: 1,
            },
          ],
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: "bottom",
            },
            title: {
              display: true,
              text: "Resumen de Tareas",
              font: {
                size: 18,
              },
            },
          },
        },
      });
    })
    .catch((error) => {
      console.error("Error al obtener datos del resumen:", error);
    });
});
