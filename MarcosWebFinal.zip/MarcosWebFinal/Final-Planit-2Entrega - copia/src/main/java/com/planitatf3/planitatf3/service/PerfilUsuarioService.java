package com.planitatf3.planitatf3.service;

import com.planitatf3.planitatf3.model.PerfilUsuario;
import com.planitatf3.planitatf3.repository.PerfilUsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PerfilUsuarioService {

    @Autowired
    private PerfilUsuarioRepository perfilUsuarioRepository;

    public Optional<PerfilUsuario> findByUserId(Long userId) {
        return Optional.ofNullable(perfilUsuarioRepository.findByUserId(userId));
    }

    public PerfilUsuario save(PerfilUsuario perfil) {
        return perfilUsuarioRepository.save(perfil);
    }
}
