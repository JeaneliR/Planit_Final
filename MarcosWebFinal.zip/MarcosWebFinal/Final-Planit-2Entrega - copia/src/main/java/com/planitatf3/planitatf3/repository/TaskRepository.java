package com.planitatf3.planitatf3.repository;

import com.planitatf3.planitatf3.model.Task;
import com.planitatf3.planitatf3.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    int countByCompletada(boolean completada);

    // ✅ EXISTENTES
    List<Task> findByUser(User user);
    int countByCompletadaAndUser(boolean completada, User user);

    // ✅ NECESARIOS PARA EL REPORTE
    long countByUserUsername(String username);
    long countByCompletadaTrueAndUserUsername(String username);
     List<Task> findByUserAndFechaVencimientoBetweenAndCompletadaFalse(User user, LocalDate desde, LocalDate hasta);

}
