package com.planitatf3.planitatf3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Planitatf3Application {

	public static void main(String[] args) {
		SpringApplication.run(Planitatf3Application.class, args);
	}

}
