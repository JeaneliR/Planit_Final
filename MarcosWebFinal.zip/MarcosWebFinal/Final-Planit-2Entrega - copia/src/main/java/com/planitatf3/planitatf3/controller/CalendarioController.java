package com.planitatf3.planitatf3.controller;

import com.planitatf3.planitatf3.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import com.planitatf3.planitatf3.security.CustomUserDetails;
import org.springframework.security.core.annotation.AuthenticationPrincipal;


import java.util.*;
import java.util.stream.Collectors;

@Controller
public class CalendarioController {

    @Autowired
    private TaskService taskService;

    @GetMapping("/calendario")
    public String verCalendario() {
        return "Calendario";
    }

  @GetMapping("/api/eventos")
@ResponseBody
public List<Map<String, Object>> obtenerEventos(@AuthenticationPrincipal CustomUserDetails userDetails) {
    var usuarioActual = userDetails.getUser();

    return taskService.findByUser(usuarioActual).stream().map(t -> {
        Map<String, Object> evento = new HashMap<>();
        evento.put("title", t.getTitulo());
        evento.put("start", t.getFechaVencimiento().toString());
        evento.put("description", t.getDescripcion());

        // Colores por prioridad
        switch (t.getPrioridad().toLowerCase()) {
            case "alta" -> evento.put("color", "#e74c3c");
            case "media" -> evento.put("color", "#f39c12");
            case "baja" -> evento.put("color", "#2ecc71");
        }

        return evento;
    }).collect(Collectors.toList());
}


}
