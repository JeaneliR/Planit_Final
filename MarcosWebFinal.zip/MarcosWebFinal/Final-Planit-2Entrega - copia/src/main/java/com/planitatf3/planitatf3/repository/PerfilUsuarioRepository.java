package com.planitatf3.planitatf3.repository;

import com.planitatf3.planitatf3.model.PerfilUsuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PerfilUsuarioRepository extends JpaRepository<PerfilUsuario, Long> {
    PerfilUsuario findByUserId(Long userId);
}
