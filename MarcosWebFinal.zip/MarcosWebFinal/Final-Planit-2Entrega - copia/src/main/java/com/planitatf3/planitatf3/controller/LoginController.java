package com.planitatf3.planitatf3.controller;

import com.planitatf3.planitatf3.model.Rol;
import com.planitatf3.planitatf3.model.User;
import com.planitatf3.planitatf3.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Mostrar formulario de login (Spring Security lo usa automáticamente)
    @GetMapping("/login")
    public String loginForm() {
        return "Login"; // Tu vista personalizada
    }

    // Mostrar formulario de registro
    @GetMapping("/registro")
    public String mostrarFormularioRegistro() {
        return "registro";
    }

    // Procesar registro
    @PostMapping("/registro")
    public String registrarUsuario(@RequestParam String username,
            @RequestParam String password,
            @RequestParam String confirmpassword,
            Model model) {

        if (!password.equals(confirmpassword)) {
            model.addAttribute("error", "Las contraseñas no coinciden");
            return "registro";
        }

        if (userRepository.findByUsername(username).isPresent()) {
            model.addAttribute("error", "El nombre de usuario ya existe");
            return "registro";
        }

        User nuevoUsuario = new User();
        nuevoUsuario.setUsername(username);
        nuevoUsuario.setPassword(passwordEncoder.encode(password)); // encriptado
        nuevoUsuario.setRol(Rol.USER); // Asignación por defecto
        userRepository.save(nuevoUsuario);

        model.addAttribute("mensaje", "Registro exitoso. Ahora puedes iniciar sesión.");
        return "redirect:/Usuario";
    }

    // Cerrar sesión ya lo maneja Spring Security con GET a /logout
}
