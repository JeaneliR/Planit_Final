package com.planitatf3.planitatf3.repository;

import com.planitatf3.planitatf3.model.Equipo;
import com.planitatf3.planitatf3.model.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EquipoRepository extends JpaRepository<Equipo, Long> {
    List<Equipo> findByMiembrosContaining(User user);
    boolean existsByNombre(String nombre); // útil para evitar duplicados
}
