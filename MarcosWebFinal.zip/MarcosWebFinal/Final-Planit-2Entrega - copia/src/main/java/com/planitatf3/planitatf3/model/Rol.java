package com.planitatf3.planitatf3.model;

public enum Rol {
    USER,
    ADMIN
}
