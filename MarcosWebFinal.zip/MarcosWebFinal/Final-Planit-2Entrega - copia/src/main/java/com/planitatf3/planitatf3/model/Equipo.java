package com.planitatf3.planitatf3.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "equipos")
public class Equipo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String nombre;

    @ManyToMany
    @JoinTable(
        name = "equipo_usuarios",
        joinColumns = @JoinColumn(name = "equipo_id"),
        inverseJoinColumns = @JoinColumn(name = "usuario_id")
    )
    private Set<User> miembros = new HashSet<>();

    public Equipo() {}

    public Equipo(String nombre) {
        this.nombre = nombre;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public Set<User> getMiembros() { return miembros; }
    public void setMiembros(Set<User> miembros) { this.miembros = miembros; }

    public void agregarMiembro(User usuario) {
        this.miembros.add(usuario);
    }

    public void removerMiembro(User usuario) {
        this.miembros.remove(usuario);
    }
}
