package com.planitatf3.planitatf3.controller;

import com.planitatf3.planitatf3.model.Equipo;
import com.planitatf3.planitatf3.model.User;
import com.planitatf3.planitatf3.security.CustomUserDetails;
import com.planitatf3.planitatf3.service.EquipoService;
import com.planitatf3.planitatf3.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/equipos")
public class EquipoController {

    @Autowired
    private EquipoService equipoService;

    @Autowired
    private UserService userService;

    // ========== ADMIN: Gestión completa ==========

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public String listarEquipos(Model model) {
        model.addAttribute("equipos", equipoService.findAll());
        model.addAttribute("nuevoEquipo", new Equipo());
        return "Equipos";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/crear")
    public String crearEquipo(@ModelAttribute Equipo nuevoEquipo) {
        if (!equipoService.existsByNombre(nuevoEquipo.getNombre())) {
            equipoService.save(nuevoEquipo);
        }
        return "redirect:/equipos";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public String verEquipo(@PathVariable Long id, Model model) {
        Equipo equipo = equipoService.findById(id).orElseThrow();
        model.addAttribute("equipo", equipo);
        model.addAttribute("usuariosDisponibles", userService.findAll());
        return "DetalleEquipo";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{equipoId}/agregar-miembro")
    public String agregarMiembro(@PathVariable Long equipoId, @RequestParam Long userId) {
        equipoService.agregarMiembro(equipoId, userId);
        return "redirect:/equipos/" + equipoId;
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{equipoId}/remover-miembro")
    public String removerMiembro(@PathVariable Long equipoId, @RequestParam Long userId) {
        equipoService.removerMiembro(equipoId, userId);
        return "redirect:/equipos/" + equipoId;
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}/editar")
    public String editarEquipo(@PathVariable Long id, Model model) {
        Equipo equipo = equipoService.findById(id).orElseThrow();
        model.addAttribute("equipo", equipo);
        return "EditarEquipo";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{id}/actualizar")
    public String actualizarEquipo(@PathVariable Long id, @RequestParam String nombre) {
        Equipo equipo = equipoService.findById(id).orElseThrow();
        equipo.setNombre(nombre);
        equipoService.save(equipo);
        return "redirect:/equipos";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{id}/eliminar")
    public String eliminarEquipo(@PathVariable Long id) {
        equipoService.deleteById(id);
        return "redirect:/equipos";
    }

    // ========== USUARIO: ver solo sus equipos ==========

    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    @GetMapping("/mis-equipos")
    public String verMisEquipos(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User usuario = userDetails.getUser();
        List<Equipo> misEquipos = equipoService.findEquiposPorUsuario(usuario);
        model.addAttribute("misEquipos", misEquipos);
        return "MisEquipos";
    }
}
