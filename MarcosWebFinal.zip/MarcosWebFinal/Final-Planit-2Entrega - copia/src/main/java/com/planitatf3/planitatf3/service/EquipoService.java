package com.planitatf3.planitatf3.service;

import com.planitatf3.planitatf3.model.Equipo;
import com.planitatf3.planitatf3.model.User;
import com.planitatf3.planitatf3.repository.EquipoRepository;
import com.planitatf3.planitatf3.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EquipoService {

    @Autowired
    private EquipoRepository equipoRepository;

    @Autowired
    private UserRepository userRepository;

    // Obtener todos los equipos
    public List<Equipo> findAll() {
        return equipoRepository.findAll();
    }

    // Buscar equipo por ID
    public Optional<Equipo> findById(Long id) {
        return equipoRepository.findById(id);
    }

    // Verificar si existe equipo por nombre
    public boolean existsByNombre(String nombre) {
        return equipoRepository.existsByNombre(nombre);
    }

    // Guardar equipo
    public Equipo save(Equipo equipo) {
        return equipoRepository.save(equipo);
    }

    // Eliminar equipo por ID
    public void deleteById(Long id) {
        equipoRepository.deleteById(id);
    }

    // Buscar los equipos en los que participa un usuario
    public List<Equipo> findEquiposPorUsuario(User user) {
        return equipoRepository.findByMiembrosContaining(user);
    }

    // Agregar miembro a un equipo
    public void agregarMiembro(Long equipoId, Long userId) {
        Optional<Equipo> equipoOpt = equipoRepository.findById(equipoId);
        Optional<User> userOpt = userRepository.findById(userId);

        if (equipoOpt.isPresent() && userOpt.isPresent()) {
            Equipo equipo = equipoOpt.get();
            User usuario = userOpt.get();

            if (!equipo.getMiembros().contains(usuario)) {
                equipo.getMiembros().add(usuario);
                equipoRepository.save(equipo);
            }
        }
    }

    // Remover miembro de un equipo
    public void removerMiembro(Long equipoId, Long userId) {
        Optional<Equipo> equipoOpt = equipoRepository.findById(equipoId);
        Optional<User> userOpt = userRepository.findById(userId);

        if (equipoOpt.isPresent() && userOpt.isPresent()) {
            Equipo equipo = equipoOpt.get();
            User usuario = userOpt.get();

            if (equipo.getMiembros().removeIf(u -> u.getId().equals(usuario.getId()))) {
                equipoRepository.save(equipo);
            }
        }
    }
}
