package com.planitatf3.planitatf3.service;

import com.planitatf3.planitatf3.model.User;
import com.planitatf3.planitatf3.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // Buscar usuario por username
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Guardar nuevo usuario con contraseña cifrada
    public User save(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    // Verificar si un username ya existe
    public boolean existsByUsername(String username) {
        return userRepository.findByUsername(username).isPresent();
    }

    // ✅ Método necesario para listar todos los usuarios (usado en EquipoController)
    public List<User> findAll() {
        return userRepository.findAll();
    }
}
