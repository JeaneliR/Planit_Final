// ReporteController.java
package com.planitatf3.planitatf3.controller;

import com.planitatf3.planitatf3.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ReporteController {

    private final TaskService taskService;

    @Autowired
    public ReporteController(TaskService taskService) {
        this.taskService = taskService;
    }

   
}
