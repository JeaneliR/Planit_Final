package com.planitatf3.planitatf3.controller;

import com.planitatf3.planitatf3.model.PerfilUsuario;
import com.planitatf3.planitatf3.security.CustomUserDetails;
import com.planitatf3.planitatf3.service.PerfilUsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PerfilUsuarioController {

    @Autowired
    private PerfilUsuarioService perfilUsuarioService;

    @GetMapping("/perfil")
    public String verPerfil(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        Long userId = userDetails.getUser().getId();

        // Buscar el perfil asociado al usuario autenticado
        PerfilUsuario perfil = perfilUsuarioService.findByUserId(userId).orElse(null);

        // Si existe, lo envías al modelo. Si no, muestras vista vacía o mensaje
        model.addAttribute("perfil", perfil);
        return "PerfilUsuario"; // Vista HTML que mostrarás
    }
}
