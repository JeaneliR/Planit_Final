package com.planitatf3.planitatf3.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "tasks")
@Data // Incluye getters, setters, equals, hashCode y toString
@NoArgsConstructor
@AllArgsConstructor
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 100, nullable = false)
    private String titulo;

    @Column(length = 255)
    private String descripcion;

    private LocalDate fechaVencimiento;

    @Column(length = 20)
    private String prioridad;

    @Column(nullable = false)
    private boolean completada;

    // 🔗 Asociación con User (cada tarea pertenece a un usuario)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}