package com.planitatf3.planitatf3.model;

import jakarta.persistence.*;

@Entity
@Table(name = "perfiles")
public class PerfilUsuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String apellido;
    private String telefono;
    private String fotoUrl;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public PerfilUsuario() {}

    public PerfilUsuario(User user, String nombre, String apellido, String telefono, String fotoUrl) {
        this.user = user;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.fotoUrl = fotoUrl;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getFotoUrl() { return fotoUrl; }
    public void setFotoUrl(String fotoUrl) { this.fotoUrl = fotoUrl; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
