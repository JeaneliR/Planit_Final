package com.planitatf3.planitatf3.controller;

import com.planitatf3.planitatf3.model.Task;
import com.planitatf3.planitatf3.model.User;
import com.planitatf3.planitatf3.repository.TaskRepository;
import com.planitatf3.planitatf3.repository.UserRepository;
import com.planitatf3.planitatf3.security.CustomUserDetails;
import com.planitatf3.planitatf3.service.TaskService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.couchbase.CouchbaseProperties.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
public class TaskController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/")
    public String mostrarInicio() {
        return "planit";
    }

    @GetMapping("/Inicio")
    public String inicio() {
        return "Inicio";
    }
@GetMapping("/MisTareas")
public String mostrarTareas(@RequestParam(name = "fecha", required = false) String fecha,
                            @AuthenticationPrincipal CustomUserDetails userDetails,
                            Model model) {
    User usuarioActual = userDetails.getUser();
    List<Task> tareas = taskService.findByUser(usuarioActual);
    List<Task> tareasProximas = taskService.obtenerTareasProximasAVencer(usuarioActual);

    model.addAttribute("tareas", tareas);
    model.addAttribute("fechaSeleccionada", fecha);
    model.addAttribute("tareasProximas", tareasProximas); // ← nuevo
    return "MisTareas";
}


    @PostMapping("/crear")
    public String crearTarea(@RequestParam String titulo,
                              @RequestParam String descripcion,
                              @RequestParam String fechaVencimiento,
                              @RequestParam String prioridad,
                              @AuthenticationPrincipal CustomUserDetails userDetails) {
        User usuarioActual = userDetails.getUser();

        Task tarea = new Task();
        tarea.setTitulo(titulo);
        tarea.setDescripcion(descripcion);
        tarea.setFechaVencimiento(LocalDate.parse(fechaVencimiento));
        tarea.setPrioridad(prioridad);
        tarea.setCompletada(false);
        tarea.setUser(usuarioActual);

        taskService.save(tarea);
        return "redirect:/MisTareas";
    }

    @PostMapping("/completar")
    public String completarTarea(@RequestParam Long id,
                                  @AuthenticationPrincipal CustomUserDetails userDetails) {
        User usuarioActual = userDetails.getUser();

        Optional<Task> optionalTarea = taskService.findById(id);
        optionalTarea.ifPresent(tarea -> {
            if (tarea.getUser().getId().equals(usuarioActual.getId())) {
                tarea.setCompletada(true);
                taskService.save(tarea);
            }
        });
        return "redirect:/MisTareas";
    }

    @PostMapping("/eliminar")
    public String eliminarTarea(@RequestParam Long id,
                                 @AuthenticationPrincipal CustomUserDetails userDetails) {
        User usuarioActual = userDetails.getUser();

        Optional<Task> optionalTarea = taskService.findById(id);
        optionalTarea.ifPresent(tarea -> {
            if (tarea.getUser().getId().equals(usuarioActual.getId())) {
                taskService.deleteById(id);
            }
        });
        return "redirect:/MisTareas";
    }

    @PostMapping("/actualizar")
    public String actualizarTarea(@RequestParam Long id,
                                  @RequestParam String titulo,
                                  @RequestParam String descripcion,
                                  @RequestParam String fechaVencimiento,
                                  @RequestParam String prioridad,
                                  @RequestParam(required = false) boolean completada,
                                  @AuthenticationPrincipal CustomUserDetails userDetails) {
        User usuarioActual = userDetails.getUser();

        Optional<Task> optionalTarea = taskService.findById(id);
        optionalTarea.ifPresent(tarea -> {
            if (tarea.getUser().getId().equals(usuarioActual.getId())) {
                tarea.setTitulo(titulo);
                tarea.setDescripcion(descripcion);
                tarea.setFechaVencimiento(LocalDate.parse(fechaVencimiento));
                tarea.setPrioridad(prioridad);
                tarea.setCompletada(completada);
                taskService.save(tarea);
            }
        });

        return "redirect:/MisTareas";
    }

    @GetMapping("/reportes")
    public String mostrarReporte(Model model, Principal principal) {
        String username = principal.getName();
        Optional<User> optionalUser = userRepository.findByUsername(username);

        if (optionalUser.isEmpty()) {
            model.addAttribute("totalTareas", 0);
            model.addAttribute("completadas", 0);
            model.addAttribute("pendientes", 0);
            return "reportes";
        }

        User user = optionalUser.get();
        int total = taskRepository.findByUser(user).size();
        int completadas = taskRepository.countByCompletadaAndUser(true, user);
        int pendientes = total - completadas;

        model.addAttribute("totalTareas", total);
        model.addAttribute("completadas", completadas);
        model.addAttribute("pendientes", pendientes);

        return "Reportes";
    }

    @GetMapping("/estadisticas")
    @ResponseBody
    public java.util.Map<String, Integer> obtenerResumen(@AuthenticationPrincipal CustomUserDetails userDetails) {
        User usuarioActual = userDetails.getUser();

        int completadas = taskService.contarPorEstadoYUsuario(true, usuarioActual);
        int pendientes = taskService.contarPorEstadoYUsuario(false, usuarioActual);

        return java.util.Map.of(
                "completadas", completadas,
                "pendientes", pendientes
        );
    }

}
