package com.planitatf3.planitatf3.service;

import com.planitatf3.planitatf3.model.Task;
import com.planitatf3.planitatf3.model.User;
import com.planitatf3.planitatf3.repository.TaskRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class TaskService {

    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public List<Task> findAll() {
        return taskRepository.findAll();
    }

    public List<Task> findByUser(User user) {
        return taskRepository.findByUser(user); // ✅ solo tareas del usuario
    }

    public Optional<Task> findById(Long id) {
        return taskRepository.findById(id);
    }

    public Task save(Task task) {
        return taskRepository.save(task);
    }

    public void deleteById(Long id) {
        taskRepository.deleteById(id);
    }

    public int contarPorEstado(boolean completada) {
        return taskRepository.countByCompletada(completada);
    }

    public int contarPorEstadoYUsuario(boolean completada, User user) {
        return taskRepository.countByCompletadaAndUser(completada, user); // ✅ por usuario
    }

    public long contarTareasPorUsuario(String username) {
    return taskRepository.countByUserUsername(username);
}

public long contarTareasCompletadasPorUsuario(String username) {
    return taskRepository.countByCompletadaTrueAndUserUsername(username);
}
public List<Task> obtenerTareasProximasAVencer(User user) {
    LocalDate hoy = LocalDate.now();
    LocalDate enDosDias = hoy.plusDays(2);
    return taskRepository.findByUserAndFechaVencimientoBetweenAndCompletadaFalse(user, hoy, enDosDias);
}

}
